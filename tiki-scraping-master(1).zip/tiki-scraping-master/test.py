string = "\u1ed4n"

string2 = string.encode('utf-8')

print(string2)